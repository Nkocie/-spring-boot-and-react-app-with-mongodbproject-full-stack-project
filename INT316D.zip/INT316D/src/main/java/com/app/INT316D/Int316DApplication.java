package com.app.INT316D;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Int316DApplication {

	public static void main(String[] args) {
		SpringApplication.run(Int316DApplication.class, args);
	}

}
