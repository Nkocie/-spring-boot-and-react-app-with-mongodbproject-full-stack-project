package com.app.INT316D;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Int316DApplicationTests {

	@Test
	void contextLoads() {
	}

}
